import platform
import os
from ctypes import cdll

module_dir = os.path.dirname(os.path.realpath(__file__))
os.environ["PATH"] += os.pathsep + module_dir

if platform.architecture()[1] == "ELF":
    try:
        cdll.LoadLibrary(module_dir + '/libowlift.so')
        cdll.LoadLibrary(module_dir + '/libopencv_world.so')
    except:
        pass
else:
    try:
        cdll.LoadLibrary('python3.dll')
    except:
        raise FileNotFoundError("python3.dll was not found (copy it to the right path)")

from .core import *
from .version import __version__
