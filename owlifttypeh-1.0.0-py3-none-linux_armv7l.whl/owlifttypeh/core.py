﻿# coding: utf-8

"""
.. only:: ja

    OWLIFT Type-H Python SDK のモジュール

.. only:: en

    OWLIFT Type-H Python SDK's module
"""

from datetime import datetime
from enum import Enum, IntEnum
import numpy as np
from threading import Thread
import time

class OwStatus(Enum):
    """
    .. only:: ja

        エラーコードを表します。

    .. only:: en

        Represents error codes.
    """

    OK = 0
    """
    .. only:: ja

        成功。

    .. only:: en

        Success.
    """
    INTERNAL_ERROR = 1
    """
    .. only:: ja

        ライブラリの内部エラー。

    .. only:: en

        Internal error in the library.
    """
    NO_MEMORY = 2
    """
    .. only:: ja

        メモリ不足。

    .. only:: en

        Not enough memory.
    """
    DEVICE_NOT_FOUND = 3
    """
    .. only:: ja

        デバイスが見つかりません。

    .. only:: en

        No device was found.
    """
    DEVICE_NOT_READY = 4
    """
    .. only:: ja

        デバイスの準備ができていません。

    .. only:: en

        Device is not ready.
    """
    DEVICE_UNSUPPORTED = 5
    """
    .. only:: ja

        サポートされていないデバイスです。

    .. only:: en

        Unsupported device.
    """
    NOT_ENOUGH_SIZE = 6
    """
    .. only:: ja

        領域のサイズが不足しています。

    .. only:: en

        Not enough size of the area.
    """
    NOT_YET = 7
    """
    .. only:: ja

        処理がまだ完了していません。

    .. only:: en

        Processing is not completed.
    """
    FIRMWARE_ERROR = 10
    """
    .. only:: ja

        デバイスのファームウェアでエラーが発生しました。

    .. only:: en

        Error occurred in device firmware.
    """
    SENSOR_ERROR = 11
    """
    .. only:: ja

        デバイスのセンサでエラーが発生しました。

    .. only:: en

        Error occurred in device sensor.
    """
    DIRECTSHOW_ERROR = 12
    """
    .. only:: ja

        DirectShowがエラーコードを返しました。

    .. only:: en

        Error occurred in DirectShow.
    """
    V4L2_ERROR = 13
    """
    .. only:: ja

        V4L2がエラーコードを返しました。

    .. only:: en

        Error occurred in V4L2.
    """
    NULL_POINTER = 20
    """
    .. only:: ja

        引数のポインタがNULLです。

    .. only:: en

        Argument as a pointer type is NULL.
    """
    INVALID_VALUE = 21
    """
    .. only:: ja

        引数の値が不正です。

    .. only:: en

        Value of argument is invalid.
    """
    INVALID_STATE = 22
    """
    .. only:: ja

        不正な状態で関数が実行されました。

    .. only:: en

        Function is called in invalid state.
    """
    FILE_IO_ERROR = 23
    """
    .. only:: ja

        ファイルI/Oエラーが発生しました。

    .. only:: en

        File I/O error occurred.
    """
    INVALID_FILE_FORMAT = 24
    """
    .. only:: ja

        不正なファイルフォーマットです。

    .. only:: en

        Invalid file format.
    """
    END_OF_FILE = 25
    """
    .. only:: ja

        ファイルの終端です。

    .. only:: en

        End of file.
    """
    INCOMPATIBLE = 26
    """
    .. only:: ja

        互換性がありません。

    .. only:: en

        Incompatible.
    """


class OwException(Exception):
    """
    .. only:: ja

        例外を表します。

    .. only:: en

        Represents exception.
    """

    def __init__(self, value):
        super(OwException, self).__init__(value)

    @property
    def status(self):
        """
        .. only:: ja

            エラーの種類。
            [読み取り専用]

        .. only:: en

            The kind of error.
            [Read only]

        :Type:      :class:`OwStatus`

        """
        # set in the extension
        return OwStatus(int(self._status))

    @property
    def host_error(self):
        """
        .. only:: ja

            ホストエラー。
            [読み取り専用]

            ホストエラーは status が :data:`OwStatus.DIRECTSHOW_ERROR`
            または :data:`OwStatus.V4L2_ERROR` のときの、
            プラットフォームに依存したエラーコードです。

        .. only:: en

            Host error.
            [Read only]

            A host error is platform-dependant error code when 'status' is
            OwStatus.DIRECTSHOW_ERROR or OwStatus.V4L2_ERROR.

        :Type:      int
        """
        # set in the extension
        return self._host_error


class OwhMeta:
    """
    .. only:: ja

        フレームに付随するデータを表します。

    .. only:: en

        Represents additional only of frame.
    """

    S_OK = 0
    """
    .. only:: ja

        :data:`status` : 通常の状態。

    .. only:: en

        TODO
    """
    S_ERROR = 1
    """
    .. only:: ja

        :data:`status` : エラーが発生して温度を取得できない状態。

    .. only:: en

        TODO
    """
    S_NO_TEMP = 2
    """
    .. only:: ja

        :data:`status` : まだ温度データを取得できない状態。
        電源ONの後、最初の数秒間取り得えます。

    .. only:: en

        TODO
    """
    S_INVALID_TEMP = 3
    """
    .. only:: ja

        :data:`status` : 温度データを取得できるが誤差が大きい状態。
        電源ONの後、約20分間取り得えます。

    .. only:: en

        TODO
    """
    EV_NONE = 0
    """
    .. only:: ja

        :data:`event_type` : イベントなし。

    .. only:: en

        TODO
    """
    EV_CORRECT = 1 << 1
    """
    .. only:: ja

        :data:`event_type` : 補正処理中に :data:`body_temp` を検知しました。

    .. only:: en

        TODO
    """
    EV_BODY_TEMP = 1 << 2
    """
    .. only:: ja

        :data:`event_type` : :data:`body_temp` を検知しました。

    .. only:: en

        TODO
    """
    EV_LOST = 1 << 3
    """
    .. only:: ja

        :data:`event_type` : 追跡していた動体を見失いました。

    .. only:: en

        TODO
    """
    EV_DIST_VALID = 1 << 4
    """
    .. only:: ja

        :data:`event_type` : 計測可能距離内に物体を検知しました。

    .. only:: en

        TODO
    """
    EV_DIST_INVALID = 1 << 5
    """
    .. only:: ja

        :data:`event_type` : 物体が計測可能距離外に出ました。

    .. only:: en

        TODO
    """
    CE_NONE = 0
    """
    .. only:: ja

        :data:`correct_error` : 成功。

    .. only:: en

        TODO
    """
    CE_TOO_HIGH = 1
    """
    .. only:: ja

        :data:`correct_error` : 検知した温度が高すぎます。
        :ref:`options <options>` の :ref:`manual_body_temp <manual_body_temp>` と比較して、
        マニュアル補正計測中に検知された体表温度が高すぎるとき返されます。

    .. only:: en

        TODO
    """
    CE_TOO_LOW = 2
    """
    .. only:: ja

        :data:`correct_error` : 検知した温度が低すぎます。
        :ref:`options <options>` の :ref:`manual_body_temp <manual_body_temp>` と比較して、
        マニュアル補正計測中に検知された体表温度が低すぎるとき返されます。

    .. only:: en

        TODO
    """

    def __init__(self):
        self._status = None
        self._file_time_ofs = None
        self._event_id = 0
        self._event_type = None
        self._body_temp = 0.0
        self._body_temp_x = 0
        self._body_temp_y = 0
        self._updated = False
        self._correct_count = 0
        self._manu_corr = 0
        self._manu_corr_ref = 0
        self._obs_temps = None
        self._temp_tab = None
        self._distance = 0
        self._current_dev_id = 0

    @property
    def status(self):
        """
        .. only:: ja

            温度データの状態。定数 OwhMeta.S_*。
            [読み取り専用]

        .. only:: en

            State of temperature data. Constants OwhMeta.S_*.
            [Read only]

        :Type:      int
        """

        return self._status

    @property
    def file_time_ofs(self):
        """
        .. only:: ja

            OWIファイルのオフセット(ミリ秒)。
            [読み取り専用]

        .. only:: en

            Offset of OWI-file (milli second).
            [Read only]

        :Type:      int
        """

        return self._file_time_ofs

    @property
    def event_id(self):
        """
        .. only:: ja

            イベントID。
            [読み取り専用]

        .. only:: en

            Event ID.
            [Read only]

        :Type:      int
        """

        return self._event_id

    @property
    def event_type(self):
        """
        .. only:: ja

            イベントタイプ。定数 OwhMeta.EV_*。
            [読み取り専用]

        .. only:: en

            Event type. Constants OwhMeta.EV_*.
            [Read only]

        :Type:      int
        """
        return self._event_type

    @property
    def body_temp(self):
        """
        .. only:: ja

            検知された温度。
            :data:`OwhMeta.EV_BODY_TEMP` イベントのとき返されます。
            [読み取り専用]

        .. only:: en

            Detected temperature.
            This property is set at event :data:`OwhMeta.EV_BODY_TEMP`.
            [Read only]

        :Type:      float
        """

        return self._body_temp

    @property
    def body_temp_x(self):
        """
        .. only:: ja

            body_temp を検知したX座標。
            :data:`OwhMeta.EV_BODY_TEMP` イベントのとき返されます。
            [読み取り専用]

        .. only:: en

            X-coodinate where body_temp is detected.
            This property is set at event :data:`OwhMeta.EV_BODY_TEMP`.
            [Read only]

        :Type:      int
        """

        return self._body_temp_x

    @property
    def body_temp_y(self):
        """
        .. only:: ja

            body_temp を検知したY座標。
            :data:`OwhMeta.EV_BODY_TEMP` イベントのとき返されます。
            [読み取り専用]

        .. only:: en

            Y-coodinate where body_temp is detected.
            This property is set at event :data:`OwhMeta.EV_BODY_TEMP`.
            [Read only]

        :Type:      int
        """

        return self._body_temp_y

    @property
    def updated(self):
        """
        .. only:: ja

            前回発行された :data:`OwhMeta.EV_BODY_TEMP` イベントに対する動体と同じ動体において、
            より高い温度が検知されたかどうか。
            :data:`OwhMeta.EV_BODY_TEMP` イベントのとき返されます。
            [読み取り専用]

        .. only:: en

            This property is set at event :data:`OwhMeta.EV_BODY_TEMP`.
            Whether or not the higher temperature is detected against
            the same moving body that was detected before.
            [Read only]

        :Type:      bool
        """

        return self._updated

    @property
    def correct_count(self):
        """
        .. only:: ja

            マニュアル補正計測における残りの検知回数。
            :data:`OwhMeta.EV_CORRECT` イベントのとき返されます。
            [読み取り専用]

        .. only:: en

            TODO
            [Read only]

        :Type:      int
        """

        return self._correct_count

    @property
    def correct_error(self):
        """
        .. only:: ja

            マニュアル補正計測でのエラー。定数 OwhMeta.CE_*。
            :data:`OwhMeta.EV_CORRECT` イベントのとき返されます。
            [読み取り専用]

        .. only:: en

            TODO
            [Read only]

        :Type:      int
        """

        return self._correct_error

    @property
    def manu_corr(self):
        """
        .. only:: ja

            マニュアル補正値(体表温度と体温の差)。
            :data:`OwhMeta.EV_CORRECT` イベントで :data:`correct_count` = 0 のときに返されます。
            [読み取り専用]

        .. only:: en

            TODO
            [Read only]

        :Type:      float
        """

        return self._manu_corr

    @property
    def manu_corr_ref(self):
        """
        .. only:: ja

            マニュアル補正計測における周辺温度に関連する値。
            :data:`OwhMeta.EV_CORRECT` イベントで :data:`correct_count` = 0 のとき返されます。
            [読み取り専用]

        .. only:: en

            TODO
            [Read only]

        :Type:      float
        """

        return self._manu_corr_ref

    @property
    def obs_temps(self):
        """
        .. only:: ja

            :ref:`options <options>` の :ref:`obs_points <obs_points>` で指定した座標の温度。
            計測可能距離内に物体を検知している間返されます。
            [読み取り専用]

        .. only:: en

            TODO
            [Read only]

        :Type:      [float, float, float]
        """

        return self._obs_temps

    @property
    def temp_tab(self):
        """
        .. only:: ja

            各画素の温度が格納された配列。
            :ref:`options <options>` の :ref:`temp_tab <temp_tab>` = True のとき返されます。
            [読み取り専用]

        .. only:: en

            TODO
            [Read only]

        :Type:      numpy.array
        """

        return self._temp_tab

    @property
    def distance(self):
        """
        .. only:: ja

            超音波センサで検知された物体との距離(mm単位)。
            検知されていないときと計測可能距離外のときは0。
            [読み取り専用]

        .. only:: en

            TODO
            [Read only]

        :Type:      [int]
        """

        return self._distance

    @property
    def current_dev_id(self):
        """
        .. only:: ja

            使用中のデバイスID (0, 1)。
            [読み取り専用]

        .. only:: en

            TODO
            [Read only]

        :Type:      [int]
        """

        return self._current_dev_id

class OwhLedStat(IntEnum):
    """
    .. only:: ja

        LEDの動作・状態を表します。

    .. only:: en

        Represents LED status.
    """
    OFF = 0
    """
    .. only:: ja

        OFF

    .. only:: en

        OFF
    """
    ON = 1
    """
    .. only:: ja

        ON

    .. only:: en

        ON
    """
    FLASH = 2
    """
    .. only:: ja

        一瞬だけON

    .. only:: en

        Flashes
    """
    BLINK_ON = 3
    """
    .. only:: ja

        最初ONから点滅

    .. only:: en

        Blinks after turning ON at first
    """
    BLINK_OFF = 4
    """
    .. only:: ja

        最初OFFから点滅

    .. only:: en

        Blinks after turning OFF at first
    """

try:
    from ._owlifttypeh_ext import \
        owh_get_lib_version, \
        owh_connect, \
        owh_open, \
        owh_release, \
        owh_get_properties, \
        owh_capture_start, \
        owh_capture_stop, \
        owh_get_frame, \
        owh_get_frame_counter, \
        owh_get_disconnected, \
        owh_run_ffc, \
        owh_get_sensor_serial_num, \
        owh_get_job, \
        owh_write_start, \
        owh_write_stop, \
        owh_set_led, \
        owh_set_options
except:
    from _owlifttypeh_ext import \
        owh_get_lib_version, \
        owh_connect, \
        owh_open, \
        owh_release, \
        owh_get_properties, \
        owh_capture_start, \
        owh_capture_stop, \
        owh_get_frame, \
        owh_get_frame_counter, \
        owh_get_disconnected, \
        owh_run_ffc, \
        owh_get_sensor_serial_num, \
        owh_get_job, \
        owh_write_start, \
        owh_write_stop, \
        owh_set_led, \
        owh_set_options

class OwhDevice:
    """
    .. only:: ja

        1組（または1個）のデバイスを表します。

    .. only:: en

        Represents the device.
    """

    _DTYPE_TEMP = np.dtype(np.float32)
    _DTYPE_IMG = np.dtype(np.uint8)

    def __init__(self, cobj):
        self._cobj = cobj
        self._worker = None
        self._running = True
        self._frame_size, self._raw_frame_size, \
                self._fwx_ofs, self._has_multi_devs = owh_get_properties(cobj)

    @classmethod
    def lib_version(cls):
        """
        .. only:: ja

            ネイティブライブラリのバージョンを返します。

            :Return:        ネイティブライブラリのバージョン。

        .. only:: en

            Returns the native library's version number.

            :Return:        The native library's version number.

        :Return Type:   (int, int, int)
        """
        return owh_get_lib_version()

    @classmethod
    def connect(cls, options = None):
        """
        .. only:: ja

            デバイスを取得します。

            * options

                常にNone。

            :Return:        :class:`OwhDevice` オブジェクト

        .. only:: en

            Get the device(s).

            :Return:        :class:`OwhDevice` object

        :Return Type:   :class:`OwhDevice`
        """
        return OwhDevice(owh_connect(options))

    @classmethod
    def open(cls, path0, path1 = None):
        """
        .. only:: ja

            OWIファイルを読み込みます。

            * path0 : str

                デバイス0のOWIファイルパス。

            * path1 : str

                デバイス1のOWIファイルパス。

            :Return:        :class:`OwhDevice` オブジェクト

        .. only:: en

            Get the device(s).

            :Return:        :class:`OwhDevice` object

        :Return Type:   :class:`OwhDevice`
        """

        if path1 is None:
            return OwhDevice(owh_open(path0))
        return OwhDevice(owh_open(path0, path1))

    def release(self):
        """
        .. only:: ja

            デバイスを解放します。

        .. only:: en

            Release the device.
        """
        owh_release(self._cobj)

    @property
    def frame_size(self):
        """
        .. only:: ja

            フレームサイズ(幅、高さ)を取得します。
            [読み取り専用]

        .. only:: en 

            Frame size (width, height).
            [Read only]

        :Type:      (int, int)

        """
        return self._frame_size

    @property
    def has_multi_devs(self):
        """
        .. only:: ja

            複数のデバイス(カメラの片眼)が接続されているかを取得します。
            [読み取り専用]

        .. only:: en 

            Returns whether or not multiple devices (one eye of camera) are connected.
            [Read only]

        :Type:      bool

        """
        return self._has_multi_devs

    @classmethod
    def _worker_proc(cls, self):
        while self._running:
            job = owh_get_job(self._cobj)
            if job is None:
                time.sleep(0.1)
            else:
                owh_run_ffc(self._cobj, job)

    def capture_start(self):
        """
        .. only:: ja

            カメラからのデータ取得を開始します。

        .. only:: en

            Starts getting data from the camera.

        """

        worker = Thread(target = OwhDevice._worker_proc, args = (self,), daemon = True)
        worker.start()
        self._worker = worker
        owh_run_ffc(self._cobj, 0)
        owh_run_ffc(self._cobj, 1)

        owh_capture_start(self._cobj)

    def capture_stop(self):
        """
        .. only:: ja

            カメラからのデータ取得を停止します。

        .. only:: en

            Stops getting data from the camera.
        """
        self._running = False
        owh_capture_stop(self._cobj)
        if self._worker is not None:
            self._worker.join()

    @property
    def frame_counter(self):
        """
        .. only:: ja

            フレームカウンタ。
            [読み取り専用]

        .. only:: en 

            Frame counter.
            [Read only]

        :Type:      int
        """
        return owh_get_frame_counter(self._cobj)

    def get_frame(self):
        """
        .. only:: ja

            画像データ、メタデータのタプル。

        .. only:: en 

            Tuple of the the image data and the meta data.

        :Type:      (bytes, :class:`OwhMeta`)
        """
        meta = OwhMeta()
        temp_buf, img_buf = owh_get_frame(self._cobj, meta)

        if temp_buf:
            meta._temp_tab = np.frombuffer(temp_buf, OwhDevice._DTYPE_TEMP) \
                .reshape(self._frame_size[1], self._frame_size[0])

        return (img_buf, meta)


    def image_to_array(self, img):
        """
        .. only:: ja

            bytes オブジェクトを numpy.array に変換します。

            * img : bytes

                :func:`get_frame` で取得した bytes オブジェクト。

        .. only:: en 

            TODO

        :Type:      numpy.array
        """

        return np.frombuffer(img, OwhDevice._DTYPE_IMG) \
            .reshape(self._frame_size[1], self._frame_size[0], 4)

    @property
    def disconnected(self):
        """
        .. only:: ja

            デバイスが切断されたかどうか。
            [読み取り専用]

        .. only:: en 

            Whether or not the device was disconnected.
            [Read only]

        :Type:      bool
        """
        return owh_get_disconnected(self._cobj)

    @property
    def alive(self):
        """
        .. only:: ja

            disconnected() と真偽逆の値。
            [読み取り専用]

        .. only:: en 

            Reverse value of disconnected().
            [Read only]

        :Type:      bool
        """
        return not self.disconnected

    def write_start(self, file0, file1 = None):
        """
        .. only:: ja

            カメラの出力をOWI形式でファイルへ保存します。

            * file0 : str

                デバイス0の出力を保存するファイル名。

            * file1 : str

                デバイス1の出力を保存するファイル名。

        .. only:: en

            TODO
        """

        if file0 is None or type(file0) != str:
            raise ValueError("file0")
        if file1 is None:
            owh_write_start(self._cobj, file0)
        else:
            if type(file1) != str:
                raise ValueError("file1")
            owh_write_start(self._cobj, file0, file1)

    def set_options(self, options):
        """
        .. only:: ja

            オプションを設定します。

            .. _options:

            * options : dict

                オプション名と値のdict型オブジェクト。

                .. _correct_mode:

                * correct_mode : int

                    マニュアル補正計測を開始する。値は計測回数

                .. _face_detect:

                * face_detect : bool

                    人体検知を行うか (デフォルト: True)

                .. _hide_bg:

                * hide_bg : bool

                    動体検知による背景削除を行うか (デフォルト: True)

                .. _image_tab:

                * image_tab : bool

                    :data:`OwhDevice.get_frame` で画像を返すか (デフォルト: True)

                .. _manu_corr:

                * manu_corr : float

                    :data:`OwhMeta.manu_corr` の値。
                    SDK利用側で取得・保存しておいた値をここで設定することで、
                    マニュアル補正計測後と同じ状態に復元されます。
                    (デフォルト: 0)

                .. _manu_corr_ref:

                * manu_corr_ref : float

                    :data:`OwhMeta.manu_corr_ref` の値。
                    SDK利用側で取得・保存しておいた値をここで設定することで、
                    マニュアル補正計測後と同じ状態に復元されます。

                .. _manual_body_temp:

                * manual_body_temp : float

                    基準値とする正式な体温計で計測した体温。
                    :ref:`correct_mode <correct_mode>`
                    でマニュアル補正計測を開始するときに設定が必要。
                    また、マニュアル補正計測の状態を復元するときは
                    :ref:`manu_corr <manu_corr>` / :ref:`manu_corr_ref <manu_corr_ref>`
                    と同時に設定します。

                .. _obs_points:

                * obs_points : [[int, int], [int, int], [int, int]]

                    :data:`OwhMeta.obs_temps` で返される温度の座標。
                    3点まで指定可能で [[x1, y1], [x2, y2], [x3, y3]] の形式で設定します。
                    X座標・Y座標の範囲は 0 .. 119 です。
                    (デフォルト: [[60, 30], [60, 60], [60, 90]])

                .. _show_target:

                * show_target : bool

                    人体検知での温度取得位置を表示するか (デフォルト: True)

                .. _target_dist:

                * target_dist : int

                    距離のよる補正の固定値(mm単位)。
                    :ref:`use_dist <use_dist>` = 2 のとき有効。

                .. _target_emiss:

                * target_emiss : float

                    測定対象の放射率 (デフォルト0.98)

                .. _temp_tab:

                * temp_tab : bool

                    :data:`OwhMeta.temp_tab` を返すか (デフォルト: False)

                .. _use_dist:

                * use_dist : int

                    距離による補正の動作

                    * 0: 距離による補正をしません
                    * 1: 距離センサの出力で補正(デフォルト)
                    * 2: :ref:`target_dist <target_dist>` の値で補正

        .. only:: en

            TODO
        """

        if options is None or type(options) != dict:
            raise ValueError("options")
        owh_set_options(self._cobj, options)

    def get_sensor_serial_num(self, id):
        """
        .. only:: ja

            赤外線センサのシリアル番号を取得します。

            * id : int

                デバイスID (0, 1)。

        .. only:: en

            TODO
        """

        return owh_get_sensor_serial_num(self._cobj, id)

    def set_led(self, r0, g0, r1, g1):
        """
        .. only:: ja

            LEDの動作・状態を変更します。

            * r0 : :class:`OwhLedStat`

                デバイス0/赤LEDの状態。

            * g0 : :class:`OwhLedStat`

                デバイス0/緑LEDの状態。

            * r1 : :class:`OwhLedStat`

                デバイス1/赤LEDの状態。

            * g1 : :class:`OwhLedStat`

                デバイス1/緑LEDの状態。

        .. only:: en

            TODO
        """

        return owh_set_led(self._cobj, int(r0), int(g0), int(r1), int(g1))

